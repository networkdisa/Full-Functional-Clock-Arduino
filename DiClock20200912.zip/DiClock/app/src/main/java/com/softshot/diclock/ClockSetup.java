package com.softshot.diclock;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.text.format.DateFormat;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextClock;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;
import com.pes.androidmaterialcolorpickerdialog.ColorPicker;

import java.util.Calendar;

public class ClockSetup extends AppCompatActivity {
    private static final String TAG = "ClockSetup";

    private TextClock displayRealTime;
    private Button btnSyncDateTime, btnSetAlarm, btnSetDate, btnSetTime,
            btnTimeFormat12, btnTimeFormat24, btnResetAlarm, btnAlarmOff,
            btnAutoColor, btnSetColor, btnVoiceEnable, btnVoiceDisable;

    //mainActivity instance for access mainActivity class methods.
    MainActivity myMainActivity = MainActivity.getInstance();
    //add LoadingDialog class
    LoaderWindow loadingDialog = new LoaderWindow(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_clock_setup);

        btnSyncDateTime = (Button)findViewById(R.id.btnSyncDateTime);
        btnTimeFormat12 = (Button)findViewById(R.id.btnTimeFormat12Hour);
        btnTimeFormat24 = (Button)findViewById(R.id.btnTimeFormat24Hour);
        btnSetAlarm = (Button)findViewById(R.id.btnSetAlarm);
        btnSetDate = (Button)findViewById(R.id.btnSetDate);
        btnSetTime = (Button)findViewById(R.id.btnSetTime);
        btnResetAlarm = (Button) findViewById(R.id.btnCancelAlrmSet);
        btnAlarmOff = (Button) findViewById(R.id.btnOfflAlrm);
        btnAutoColor = (Button) findViewById(R.id.btnAutoColor);
        btnSetColor = (Button) findViewById(R.id.btnSetColor);
        btnVoiceEnable = (Button) findViewById(R.id.btnVoiceEnable);
        btnVoiceDisable = (Button) findViewById(R.id.btnVoiceDisable);


    }//end of onCreate

    /*
    loader window loading method
     */
    void loadingDialogRapper(){
        loadingDialog.startLoadingDialog();
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                loadingDialog.dismissDialog();
            }
        },1000);
    }

    /*
    Custom snackBar method
     */
    public void mySnackBar(String message){
        Snackbar snackbar = Snackbar.make(findViewById(android.R.id.content), message, Snackbar.LENGTH_LONG);
        View snackbarView = snackbar.getView();
        TextView textView = snackbarView.findViewById(R.id.snackbar_text);
        textView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18); //snackbar text size
        snackbar.getView().setBackgroundColor(Color.rgb(227, 38, 54)); //snackbar background
        //centering text
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            textView.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        }else {
            textView.setGravity(Gravity.CENTER_HORIZONTAL);
        }
        textView.setGravity(Gravity.CENTER_HORIZONTAL);

        snackbar.show();
    }


    /*
    sync with mobile date time when "SYNC WITH YOUR MOBILE DATE / TIME" BUTTON
     */
    public void syncMobileDateTime(View view) {
        Calendar calendar = Calendar.getInstance();

        int year = calendar.get(calendar.YEAR);
        int month = calendar.get(calendar.MONTH) + 1;
        int date = calendar.get(calendar.DATE);
        int hour24 = calendar.get(calendar.HOUR_OF_DAY); //hour in 24 hour format
        int hour12 = calendar.get(calendar.HOUR); //hour in 12 hour format
        int minute = calendar.get(calendar.MINUTE);
        int second = calendar.get(calendar.SECOND);
        Log.d(TAG, "syncMobilrCLICKED");
        String dateTimeString = "A" + hour24 + "," + minute + "," + second + "," + month + "," + date + "," + year + ",";
        String txtDateTimeString = year + "-" + month + "-" + date + "  ---  " + hour12 + ":" + minute + ":" + second;

        myMainActivity.sendData(dateTimeString);

        loadingDialogRapper();

        mySnackBar(txtDateTimeString + " sent to clock");

        Log.d(TAG, dateTimeString);
    }

    /*
    set 12 hours time format when "12 HOUR TIME FORMAT" BUTTON
     */
    public void setTimeFormat12Hour(View view) {
        myMainActivity.sendData("B");
        loadingDialogRapper();
        mySnackBar("Clock time display in 12 hour format");
    }

    /*
    set 24 hours time format when "24 HOUR TIME FORMAT" BUTTON
     */
    public void setTimeFormat24Hour(View view) {
        myMainActivity.sendData("C");
        loadingDialogRapper();
        mySnackBar("Clock time display in 24 hour format");
    }

    /*
    set alarm to clock when "SET ALARM" BUTTON
     */
    public void setAlarm(View view) {
        Calendar calendar = Calendar.getInstance();
        int hourNow = calendar.get(Calendar.HOUR);
        int minuteNow = calendar.get(Calendar.MINUTE);

        boolean is24HourFormat = DateFormat.is24HourFormat(this); //check device settings for time to display

        TimePickerDialog timePickerDialog = new TimePickerDialog(this, new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hour, int minute) {
                String timeStringAlarm = "D" + hour + "," + minute + ",";
                myMainActivity.sendData(timeStringAlarm);
                loadingDialogRapper();
                String txtTimeStringAlarm = hour + ":" + minute + ":" + "00 Alarm Set on clock";
                mySnackBar(txtTimeStringAlarm);
            }
        }, hourNow, minuteNow, is24HourFormat);

        timePickerDialog.show();
    }

    /*
    Cancel Alarm when "CANCEL ALARM" BUTTON
     */
    public void cancelAlarm(View view) {
        myMainActivity.sendData("E");
        loadingDialogRapper();
        mySnackBar("Alarm cancelled, Have a good day!");
    }

     /*
    Alarm Off when "ALARM OFF" BUTTON
     */
     public void alarmOff(View view) {
         myMainActivity.sendData("F");
         loadingDialogRapper();
         mySnackBar("WakeUp Bro.., Alarm turned Off");
     }

      /*
        set only date when "SET DATE" BUTTON
     */
      public void setDate(View view) {
          Calendar calendar = Calendar.getInstance();
          int yearNow = calendar.get(Calendar.YEAR);
          int monthNow = calendar.get(Calendar.MONTH);;
          int dateNow = calendar.get(Calendar.DATE);

          DatePickerDialog datePickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
              @Override
              public void onDateSet(DatePicker view, int year, int month, int day) {
                  int monthVal= month + 1;
                  String dateString = "H" + monthVal + "," + day + "," + year + ",";
                  myMainActivity.sendData(dateString);
                  loadingDialogRapper();
                  String txtDateString = year + "/" + monthVal + "/" + day + " Set on clock";
                  mySnackBar(txtDateString);
              }
          },yearNow, monthNow, dateNow);

          datePickerDialog.show();
      }

      /*
        set only time when "SET TIME" BUTTON
     */
      public void setTime(View view) {
          Calendar calendar = Calendar.getInstance();
          int hourNow = calendar.get(Calendar.HOUR);
          int minuteNow = calendar.get(Calendar.MINUTE);

          boolean is24HourFormat = DateFormat.is24HourFormat(this); //check device settings for time to display

          TimePickerDialog timePickerDialog = new TimePickerDialog(this, new TimePickerDialog.OnTimeSetListener() {
              @Override
              public void onTimeSet(TimePicker view, int hour, int minute) {
                  String timeString = "G" + hour + "," + minute + ",";
                  myMainActivity.sendData(timeString);
                  loadingDialogRapper();
                  String txtTimeString = hour + ":" + minute + ":" + "00 Set on clock";
                  mySnackBar(txtTimeString);
              }
          }, hourNow, minuteNow, is24HourFormat);

          timePickerDialog.show();
      }

      /*
        set auto change clock led color when "MULTIPLE COLOR" BUTTON
     */
      public void colorMode(View view) {
          myMainActivity.sendData("I");
          loadingDialogRapper();
          mySnackBar("LED auto color change mode ON");
      }

      /*
        Set manual LED Color when "SELECTED COLOR" BUTTON
     */
      public void setColor(View view) {
          final ColorPicker colorPicker = new ColorPicker(this, 110, 198, 83);
          colorPicker.show();

          /* On Click listener for the dialog, when the user select the color */
          Button okColor = (Button)colorPicker.findViewById(R.id.okColorButton);
          okColor.setOnClickListener(new View.OnClickListener() {
              @Override
              public void onClick(View v) {
                  /* You can get single channel (value 0-255) */
                  int colorRed = colorPicker.getRed();
                  int colorGreen = colorPicker.getGreen();
                  int colorBlue = colorPicker.getBlue();
                  String colorString = "J" + colorRed + "," + colorGreen + "," + colorBlue + ",";
                  //Log.d("selectColor", colorString);
                  myMainActivity.sendData(colorString);

                  colorPicker.dismiss();

                  mySnackBar("Color Changed & LED auto color mode OFF");
              }
          });
      }

      /*
        enable time telling voice in each hour when "VOICE ENABLE" BUTTON
     */
      public void voiceEnable(View view) {
          myMainActivity.sendData("K");
          loadingDialogRapper();
          mySnackBar("Clock voice turned On");
      }

    /*
      disable time telling voice in each hour when "VOICE DISABLE" BUTTON
   */
    public void voiceDisable(View view) {
        myMainActivity.sendData("L");
        loadingDialogRapper();
        mySnackBar("Clock voice turned Off");
    }

    /*
      Adjust the light color density when "ADJUST CLOCK BACKLIGHT" BUTTON
   */
    public void adjBackLight(View view) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Adjust clock backlight");

        final SeekBar seekBar = new SeekBar(ClockSetup.this);
        final int step = 1; //https://stackoverflow.com/questions/20762001/how-to-set-seekbar-min-and-max-value
        final int max = 255;
        final int min = 30;
        seekBar.setMax( (max - min) / step );

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT);
        seekBar.setLayoutParams(lp);
        builder.setView(seekBar);
        builder.setPositiveButton("ADJUST", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                //Toast.makeText(getApplicationContext(), "Progress is " + seekBar.getProgress(), Toast.LENGTH_SHORT).show();
                double val = min + (seekBar.getProgress() * step); //to get value between min and max
                int seekBarVal = (int) val; //convert to int
                String adjValString = "M" + seekBarVal +",";

                myMainActivity.sendData(adjValString);

                mySnackBar("Light level set to " + seekBarVal + " and Auto brightness mode disabled");
            }
        });
        builder.show();
    }

    /*
      Adjust the volume of voice when "ADJUST VOLUME OF VOICE" BUTTON
   */
    public void adjustVolume(View view) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Adjust volume of voice");

        final SeekBar seekBar = new SeekBar(ClockSetup.this);
        final int step = 1; //https://stackoverflow.com/questions/20762001/how-to-set-seekbar-min-and-max-value
        final int max = 30;
        final int min = 1;
        seekBar.setMax( (max - min) / step );

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT);
        seekBar.setLayoutParams(lp);
        builder.setView(seekBar);
        builder.setPositiveButton("ADJUST VOICE", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                //Toast.makeText(getApplicationContext(), "Progress is " + seekBar.getProgress(), Toast.LENGTH_SHORT).show();
                double val = min + (seekBar.getProgress() * step); //to get value between min and max
                int seekBarVal = (int) val; //convert to int
                String adjVolString = "N" + seekBarVal +",";

                myMainActivity.sendData(adjVolString);

                mySnackBar("Volume of voice set to " + seekBarVal);
            }
        });
        builder.show();
    }

    public void autoAdjBackLight(View view) {
        myMainActivity.sendData("P");
        loadingDialogRapper();
        mySnackBar("Enable backlight auto adjustment mode");
    }
}//end of Class
