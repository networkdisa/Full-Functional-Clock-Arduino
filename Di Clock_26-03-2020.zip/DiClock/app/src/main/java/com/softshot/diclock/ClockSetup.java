package com.softshot.diclock;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.TextClock;
import android.widget.TextView;

import com.google.android.material.snackbar.Snackbar;

import java.util.Calendar;

public class ClockSetup extends AppCompatActivity {
    private static final String TAG = "ClockSetup";

    private TextClock displayRealTime;
    private Button btnSyncDateTime, btnSetAlarm, btnSetDate, btnSetTime,
            btnTimeFormat12, btnTimeFormat24, btnResetAlarm, btnAlarmOff,
            btnAutoColor, btnSetColor, btnVoiceEnable, btnVoiceDisable;

    //mainActivity instance for access mainActivity class methods.
    MainActivity myMainActivity = MainActivity.getInstance();
    //add LoadingDialog class
    LoaderWindow loadingDialog = new LoaderWindow(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_clock_setup);

        btnSyncDateTime = (Button)findViewById(R.id.btnSyncDateTime);
        btnTimeFormat12 = (Button)findViewById(R.id.btnTimeFormat12Hour);
        btnTimeFormat24 = (Button)findViewById(R.id.btnTimeFormat24Hour);
        btnSetAlarm = (Button)findViewById(R.id.btnSetAlarm);
        btnSetDate = (Button)findViewById(R.id.btnSetDate);
        btnSetTime = (Button)findViewById(R.id.btnSetTime);
        btnResetAlarm = (Button) findViewById(R.id.btnCancelAlrmSet);
        btnAlarmOff = (Button) findViewById(R.id.btnOfflAlrm);
        btnAutoColor = (Button) findViewById(R.id.btnAutoColor);
        btnSetColor = (Button) findViewById(R.id.btnSetColor);
        btnVoiceEnable = (Button) findViewById(R.id.btnVoiceEnable);
        btnVoiceDisable = (Button) findViewById(R.id.btnVoiceDisable);


    }//end of onCreate

    /*
    loader window loading method
     */
    void loadingDialogRapper(){
        loadingDialog.startLoadingDialog();
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                loadingDialog.dismissDialog();
            }
        },1800);
    }

    /*
    Custom snackBar method
     */
    public void mySnackBar(String message){
        Snackbar snackbar = Snackbar.make(findViewById(android.R.id.content), message, Snackbar.LENGTH_LONG);
        View snackbarView = snackbar.getView();
        TextView textView = snackbarView.findViewById(R.id.snackbar_text);
        textView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18); //snackbar text size
        snackbar.getView().setBackgroundColor(Color.rgb(227, 38, 54)); //snackbar background
        //centering text
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            textView.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        }else {
            textView.setGravity(Gravity.CENTER_HORIZONTAL);
        }
        textView.setGravity(Gravity.CENTER_HORIZONTAL);
        
        snackbar.show();
    }


    /*
    sync with mobile date time when "SYNC WITH YOUR MOBILE DATE / TIME" BUTTON
     */
    public void syncMobileDateTime(View view) {
        Calendar calendar = Calendar.getInstance();

        int year = calendar.get(calendar.YEAR);
        int month = calendar.get(calendar.MONTH) + 1;
        int date = calendar.get(calendar.DATE);
        int hour24 = calendar.get(calendar.HOUR_OF_DAY); //hour in 24 hour format
        int hour12 = calendar.get(calendar.HOUR); //hour in 12 hour format
        int minute = calendar.get(calendar.MINUTE);
        int second = calendar.get(calendar.SECOND);
        Log.d(TAG, "syncMobilrCLICKED");
        String dateTimeString = "A" + hour24 + "," + minute + "," + second + "," + month + "," + date + "," + year + ",";
        String txtDateTimeString = year + "-" + month + "-" + date + "  ---  " + hour12 + ":" + minute + ":" + second;
        myMainActivity.sendData(dateTimeString);
        loadingDialogRapper();
        //txtStatus.setText(txtDateTimeString + "  sent to clock");
        //Snackbar snackbar = Snackbar.make(findViewById(android.R.id.content), txtDateTimeString + " sent to clock", Snackbar.LENGTH_LONG);
        //snackbar.show();
        mySnackBar(txtDateTimeString + " sent to clock");


    }



}//end of Class
