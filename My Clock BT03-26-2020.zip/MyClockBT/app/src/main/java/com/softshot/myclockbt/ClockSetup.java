package com.softshot.myclockbt;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextClock;
import android.widget.TextView;
import android.widget.TimePicker;
import com.pes.androidmaterialcolorpickerdialog.ColorPicker;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.StringTokenizer;

public class ClockSetup extends AppCompatActivity {

    private TextClock displayRealTime;
    private TextView txtStatus;
    private Button btnSyncDateTime, btnSetAlarm, btnSetDate, btnSetTime,
            btnTimeFormat12, btnTimeFormat24, btnResetAlarm, btnAlarmOff, btnAutoColor, btnSetColor;

    MainActivity myMainActivity = MainActivity.getInstance();
    //add LoadingDialog class
    final LoadingDialog loadingDialog = new LoadingDialog(ClockSetup.this);


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_clock_setup);

        displayRealTime = (TextClock) findViewById(R.id.txtDisplayDateTime);
        txtStatus = (TextView) findViewById(R.id.txtActiveStatus);
        btnSyncDateTime = (Button)findViewById(R.id.btnSyncDateTime);
        btnTimeFormat12 = (Button)findViewById(R.id.btnTimeFormat12Hour);
        btnTimeFormat24 = (Button)findViewById(R.id.btnTimeFormat24Hour);
        btnSetAlarm = (Button)findViewById(R.id.btnSetAlarm);
        btnSetDate = (Button)findViewById(R.id.btnSetDate);
        btnSetTime = (Button)findViewById(R.id.btnSetTime);
        btnResetAlarm = (Button) findViewById(R.id.btnCancelAlrmSet);
        btnAlarmOff = (Button) findViewById(R.id.btnOfflAlrm);
        btnAutoColor = (Button) findViewById(R.id.btnAutoColor);
        btnSetColor = (Button) findViewById(R.id.btnSetColor);


        /*btnSyncDateTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String dateTimedata = new SimpleDateFormat("HH,mm,ss,MM,dd,yyyy", Locale.getDefault()).format(new Date()); //YYYY,MM,DD,HH,MIN,Sec

                myMainActivity.sendData("A" + dateTimedata + ",");
                txtSyncWithMobile.setText(dateTimedata + "set to clock");

                loadingDialogRapper();
            }
        });*/

    }


    void btnSendTestData(View view) {
        //myMainActivity.sendData("1");
        //MainActivity myMainActivity = MainActivity.getInstance();
        myMainActivity.sendData("1b");
    }

    void loadingDialogRapper(){
        loadingDialog.startLoadingDialog();
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                loadingDialog.dismissDialog();
            }
        },1800);
    }

    //sync with mobile date time
    public void syncMobileDateTime(View view) {
        /*String dateTimedata = new SimpleDateFormat("HH,mm,ss,MM,dd,yyyy", Locale.getDefault()).format(new Date()); //YYYY,MM,DD,HH,MIN,Sec

        myMainActivity.sendData("A" + dateTimedata + ",");
        txtStatus.setText(dateTimedata + "set to clock");

        loadingDialogRapper();*/

        Calendar calendar = Calendar.getInstance();

        int year = calendar.get(calendar.YEAR);
        int month = calendar.get(calendar.MONTH) + 1;
        int date = calendar.get(calendar.DATE);
        int hour24 = calendar.get(calendar.HOUR_OF_DAY); //hour in 24 hour format
        int hour12 = calendar.get(calendar.HOUR); //hour in 12 hour format
        int minute = calendar.get(calendar.MINUTE);
        int second = calendar.get(calendar.SECOND);


        String dateTimeString = "A" + hour24 + "," + minute + "," + second + "," + month + "," + date + "," + year + ",";
        String txtDateTimeString = year + "-" + month + "-" + date + "  ---  " + hour12 + ":" + minute + ":" + second;
        myMainActivity.sendData(dateTimeString);
        loadingDialogRapper();
        txtStatus.setText(txtDateTimeString + "  sent to clock");

    }

    //set 12 hours time format
    public void setTimeFormat12Hour(View view) {
        myMainActivity.sendData("B");
        loadingDialogRapper();
        txtStatus.setText("Clock set to 12 Hour format");
    }

    //set 24 hours time format
    public void setTimeFormat24Hour(View view) {
        myMainActivity.sendData("C");
        loadingDialogRapper();
        txtStatus.setText("Clock set to 24 Hour format");
    }

    //set alarm to clock
    public void setAlarm(View view) {
        Calendar calendar = Calendar.getInstance();
        int hourNow = calendar.get(Calendar.HOUR);
        int minuteNow = calendar.get(Calendar.MINUTE);

        TimePickerDialog timePickerDialog = new TimePickerDialog(this, new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hour, int minute) {
                String timeStringAlarm = "D" + hour + "," + minute + ",";
                myMainActivity.sendData(timeStringAlarm);
                loadingDialogRapper();
                String txtTimeStringAlarm = hour + ":" + minute + ":" + "00 Alarm Set on clock";
                txtStatus.setText(txtTimeStringAlarm);
            }
        }, hourNow, minuteNow, true);

        timePickerDialog.show();
    }

    //Cancel Alarm
    public void cancelAlarm(View view) {
        myMainActivity.sendData("E");
        loadingDialogRapper();
        txtStatus.setText("Alarm reset completed");
    }

    //Alarm Off
    public void alarmOff(View view) {
        myMainActivity.sendData("F");
        loadingDialogRapper();
        txtStatus.setText("WakeUp man, Alarm Off");
    }

    //set only date
    public void setDate(View view) {
        Calendar calendar = Calendar.getInstance();
        int yearNow = calendar.get(Calendar.YEAR);
        int monthNow = calendar.get(Calendar.MONTH);;
        int dateNow = calendar.get(Calendar.DATE);

        DatePickerDialog datePickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int day) {
                int monthVal= month + 1;
                String dateString = "H" + monthVal + "," + day + "," + year + ",";
                myMainActivity.sendData(dateString);
                loadingDialogRapper();
                String txtDateString = year + "/" + monthVal + "/" + day + " Set on clock";
                txtStatus.setText(txtDateString);
            }
        },yearNow, monthNow, dateNow);

        datePickerDialog.show();
    }

    //set only time
    public void setTime(View view) {
        Calendar calendar = Calendar.getInstance();
        int hourNow = calendar.get(Calendar.HOUR);
        int minuteNow = calendar.get(Calendar.MINUTE);

        TimePickerDialog timePickerDialog = new TimePickerDialog(this, new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hour, int minute) {
                String timeString = "G" + hour + "," + minute + ",";
                myMainActivity.sendData(timeString);
                loadingDialogRapper();
                String txtTimeString = hour + ":" + minute + ":" + "00 Set on clock";
                txtStatus.setText(txtTimeString);
            }
        }, hourNow, minuteNow, true);

        timePickerDialog.show();
    }

    //set auto change clock led color
    public void colorMode(View view) {
        myMainActivity.sendData("I");
        loadingDialogRapper();
        txtStatus.setText("LED auto color change mode ON");
    }

    //Set manual LED Color
    public void setColor(View view) {
        final ColorPicker colorPicker = new ColorPicker(this, 120, 100, 70);
        colorPicker.show();

        /* On Click listener for the dialog, when the user select the color */
        Button okColor = (Button)colorPicker.findViewById(R.id.okColorButton);
        okColor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                /* You can get single channel (value 0-255) */
                int colorRed = colorPicker.getRed();
                int colorGreen = colorPicker.getGreen();
                int colorBlue = colorPicker.getBlue();
                String colorString = "J" + colorRed + "," + colorGreen + "," + colorBlue + ",";
                //Log.d("selectColor", colorString);

                colorPicker.dismiss();

                txtStatus.setText("Color Changed & LED auto color mode OFF");
            }
        });
    }



}//END OF CLASS
