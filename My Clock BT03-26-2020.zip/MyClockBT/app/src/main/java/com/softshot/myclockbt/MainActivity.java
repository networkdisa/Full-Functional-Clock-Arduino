package com.softshot.myclockbt;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {

    static MainActivity instance;//01-make instance of MainActivity for access from ClockSetup activity

    TextView btStatus; //bluetooth status text view
    Button btOn; //bluetooth on button
    Button btOff; //bluetooth off button
    Button showPaired; //show paired devices button
    ListView listDevices;  //listView for paired / discover devices
    Button btnTestVal;
    Button clockSetup; //button for go to setup clock screen

    private Set<BluetoothDevice> myPairedDevices; //Set is A collection that contains no duplicate elements
    private ArrayAdapter<String> myArrayAdapter;  //for Listview

    //private Handler myHandler; // Our main handler that will receive callback notifications

    BluetoothAdapter myBluetoothAdapter; //creating object of BluetoothAdapter.
    private BluetoothSocket myBTSocket = null; // bi-directional client-to-client data path
    private ConnectedThread myConnectedThread; // bluetooth background worker thread to send and receive data

    //int object for enable the BlueTooth
    int REQUEST_ENABLE_BLUETOOTH = 1;

    // "random" unique identifier for initiate connectivity
    private static final UUID BTMODULEUUID  = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    //constants for Handler usability
    private final static int MESSAGE_READ = 2; // used in bluetooth handler to identify message update
    private final static int CONNECTING_STATUS = 3; // used in bluetooth handler to identify message status


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        instance = this;//02-make instance of MainActivity for access from ClockSetup activity

        findViewByIdes(); //initialize all UI components.

        clockSetup.setVisibility(View.GONE); //change visibility of setup clock button.

        myBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        checkBluetoothStatus(); //check bluetooth status when ui start

        //register broadcast receiver for find real time bluetooth status change
        IntentFilter filter1 = new IntentFilter(myBluetoothAdapter.ACTION_STATE_CHANGED);
        registerReceiver(myReceiver1, filter1);
        //register broadcasteceiver for find connected bluetooth device is disconnected.(the disconnected status showing after 15seconds)
        IntentFilter f1 = new IntentFilter(BluetoothDevice.ACTION_ACL_DISCONNECT_REQUESTED);
        IntentFilter f2 = new IntentFilter(BluetoothDevice.ACTION_ACL_DISCONNECTED);
        this.registerReceiver(myReceiver2, f1);
        this.registerReceiver(myReceiver2, f2);


        //assign array adapter to ListView and it format(simple_list_item_1)
        myArrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1);
        listDevices.setAdapter(myArrayAdapter);
        listDevices.setOnItemClickListener(myDeviceListClick); //ListView item click event

        bluetoothOn(); //turn on bluetooth

    }

    //03-make instance of MainActivity for access from ClockSetup activity
    public static MainActivity getInstance(){
        return instance;
    }



    //Handler object for update UI while running background Thread
    Handler myHandler = new Handler() {
        public void handleMessage(android.os.Message msg){
            if(msg.what == CONNECTING_STATUS){
                if(msg.arg1 == 1){
                    btStatus.setText("Connected to Device: " + (String)(msg.obj));
                    gotoIntent();
                    clockSetup.setVisibility(View.VISIBLE);
                }else {
                    btStatus.setText("Connection Failed");
                }
            }

            if(msg.what == MESSAGE_READ){
                String readMessage = null;
                try {
                    readMessage = new String((byte[]) msg.obj, "UTF-8");
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                }
            }
        }
    };

    //method for instantiate UI elements
    private void findViewByIdes() {
        btStatus = (TextView) findViewById(R.id.txtBtStatus);
        btOn = (Button) findViewById(R.id.btnBtOn);
        btOff = (Button) findViewById(R.id.btnBtOff);
        showPaired = (Button) findViewById(R.id.btnPairedDevices);
        listDevices = (ListView) findViewById(R.id.listViewForDevices);
        btnTestVal = (Button) findViewById(R.id.btnSendTestVal);
        clockSetup = (Button) findViewById(R.id.btnSetupClock);
    }

    private void checkBluetoothStatus() {
        if(myBluetoothAdapter.isEnabled()){
            btStatus.setText("Bluetooth Enabled");
            btOn.setEnabled(false);
        }else{
            btStatus.setText("Bluetooth Disabled");
            btOff.setEnabled(false);
        }
    }

    //bluetooth On method
    private void bluetoothOn() {
        if(!myBluetoothAdapter.isEnabled()) {
            Intent enableIntent = new Intent(myBluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableIntent, REQUEST_ENABLE_BLUETOOTH);  //ask enable bluetooth with system intent
        }else{
            Toast.makeText(getBaseContext(), "Bluetooth already turned on", Toast.LENGTH_LONG).show();
        }
    }

    //show paired devices method
    private void showPairedDevices(){
        myPairedDevices = myBluetoothAdapter.getBondedDevices();
        if(myBluetoothAdapter.isEnabled()){
            /*if(myBluetoothAdapter.isDiscovering()){ //check bluetooth discovery process running, if it is stop it
                myBluetoothAdapter.cancelDiscovery();
            }*/

            myArrayAdapter.clear(); //clear existing content
            for (BluetoothDevice device : myPairedDevices){
                //add checking for only show paired clocks.
                myArrayAdapter.add(device.getName() + "\n" + device.getAddress()); //
                Toast.makeText(getApplicationContext(), "Paired devices listing completed", Toast.LENGTH_LONG).show();
            }
        }else {
            Toast.makeText(getApplicationContext(), "Bluetooth not enabled", Toast.LENGTH_LONG).show();
        }

    }

    //Discover new bluetooth devices method
    private void discoverDevices(){
        if(myBluetoothAdapter.isDiscovering()){ //check discovery process already running
            myBluetoothAdapter.cancelDiscovery();
            Toast.makeText(getApplicationContext(), "Bluetooth discovery process Stopped", Toast.LENGTH_LONG).show();
        }else {
            if(myBluetoothAdapter.isEnabled()){
                myArrayAdapter.clear(); //clear existing content
                myBluetoothAdapter.startDiscovery();
                Toast.makeText(getApplicationContext(), "Bluetooth discovery process Started", Toast.LENGTH_LONG).show();
                registerReceiver(myReceiver1, new IntentFilter(BluetoothDevice.ACTION_FOUND));
            }else{
                Toast.makeText(getApplicationContext(), "Bluetooth not enabled", Toast.LENGTH_LONG).show();
            }

        }
    }


    //"BLUETOOTH ON" Button click
    public void btnBluetoothOn(View view) {
        bluetoothOn();
    }

    //"BLUETOOTH OFF" button click
    public void btnBluetoothOff(View view) {
        myBluetoothAdapter.disable();
    }

    //"SHOW PAIRED DEVICES" button click
    public void btnShowPairedDevices(View view) {
        showPairedDevices();
    }

    //"DISCOVER DEVICES" button click
    public void btnDiscoverDevices(View view) {
        discoverDevices();
    }

    public void btnSendTestVal(View view) {
        //if(myConnectedThread != null){
        //myConnectedThread.write("1");
        //}
        sendData("1");
    }
    //public function for send data to connected device
    public void sendData(String data){
        if(myConnectedThread != null){
            myConnectedThread.write(data);
        }
    }

    //"SETUP CLOCK" button click
    public void btnSetupClock(View view) {
        //go to the "setup clock" intent-screen
        Intent setupClockIntent = new Intent(this, ClockSetup.class);
        startActivity(setupClockIntent);
    }
    public void gotoIntent(){
        Intent setupClockIntent = new Intent(this, ClockSetup.class);
        startActivity(setupClockIntent);
    }



    //broadcast receiver for current bluetooth status change check
    private final BroadcastReceiver myReceiver1 = new BroadcastReceiver() { //https://stackoverflow.com/questions/9693755/detecting-state-changes-made-to-the-bluetoothadapter
        @Override
        public void onReceive(Context context, Intent intent) {
            final String action = intent.getAction();
            //bluetooth status change capture
            if (action.equals(BluetoothAdapter.ACTION_STATE_CHANGED)) {
                final int state = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE,
                        BluetoothAdapter.ERROR);
                switch (state) {
                    case BluetoothAdapter.STATE_OFF:
                        btStatus.setText("Bluetooth off");
                        btOn.setEnabled(true);
                        btOff.setEnabled(false);
                        clockSetup.setVisibility(View.GONE);
                        break;
                    case BluetoothAdapter.STATE_TURNING_OFF:
                        btStatus.setText("Turning Bluetooth off...");
                        break;
                    case BluetoothAdapter.STATE_ON:
                        btStatus.setText("Bluetooth on");
                        btOn.setEnabled(false);
                        btOff.setEnabled(true);
                        break;
                    case BluetoothAdapter.STATE_TURNING_ON:
                        btStatus.setText("Turning Bluetooth on...");
                        break;
                }
            }
            //bluetooth discovery process find devices arrange to ListView
            if(BluetoothDevice.ACTION_FOUND.equals(action)){
                BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE); //retrieve external data from intent
                // add the name to the list
                myArrayAdapter.add(device.getName() + "\n" + device.getAddress());
                myArrayAdapter.notifyDataSetChanged(); //refresh listview when change occur

            }
        }
    };

    ////Connected device status check--disconnection from a remote bluetooth device.
    private final BroadcastReceiver myReceiver2 = new BroadcastReceiver() {

        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();

            if (BluetoothDevice.ACTION_ACL_DISCONNECTED.equals(action)){ //take 15 seconds to catch this status
                btStatus.setText("Device disconnected");
                clockSetup.setVisibility(View.GONE);
            }
        }
    };

    //add BluetoothSocket to connected deviceMac and return it attaching UUID
    private BluetoothSocket createBluetoothSocket(BluetoothDevice device) throws IOException {
        return  device.createRfcommSocketToServiceRecord(BTMODULEUUID);
        //creates secure outgoing connection with BT device using UUID
    }

    //listview click event method
    private AdapterView.OnItemClickListener myDeviceListClick =new AdapterView.OnItemClickListener() {
        @Override
        public void onItemClick(AdapterView<?> parent, View v, int position, long id) {
            if(!myBluetoothAdapter.isEnabled()){
                Toast.makeText(getApplicationContext(), "Bluetooth not On", Toast.LENGTH_LONG).show();
                return;
            }

            btStatus.setText("Connecting...");

            // Get the device MAC address, which is the last 17 chars in the View
            String deviceInfo = ((TextView) v).getText().toString();
            final String deviceMac = deviceInfo.substring(deviceInfo.length() - 17);
            final String deviceName = deviceInfo.substring(0,deviceInfo.length() - 17);

            //thread that initiates a Bluetooth connection
            new Thread(){
                public void run(){
                    boolean fail = false; //for mark socket creation status

                    BluetoothDevice device = myBluetoothAdapter.getRemoteDevice(deviceMac);

                    try {
                        myBTSocket = createBluetoothSocket(device);
                    } catch (IOException e) {
                        fail = true;
                        Toast.makeText(getApplicationContext(), "Socket creation fail", Toast.LENGTH_LONG).show();
                    }
                    // Establish the Bluetooth socket connection.
                    try {
                        myBTSocket.connect();
                    } catch (IOException e) {
                        try {
                            fail = true;
                            myBTSocket.close();
                            myHandler.obtainMessage(CONNECTING_STATUS, -1, -1) .sendToTarget();
                        } catch (IOException e2) {
                            //insert code to deal with this
                            Toast.makeText(getApplicationContext(), "Socket creation fail", Toast.LENGTH_LONG).show();
                        }
                    }
                    if(fail == false){
                        myConnectedThread = new ConnectedThread(myBTSocket);
                        myConnectedThread.start();

                        myHandler.obtainMessage(CONNECTING_STATUS, 1, -1, deviceName).sendToTarget();
                    }
                }
            }.start();
        }
    };



    //Bluetooth thread for RX/TX
    private class ConnectedThread extends Thread{
        private final BluetoothSocket mySocket;
        private final InputStream myInStream;
        private final OutputStream myOutStream;

        public ConnectedThread(BluetoothSocket socket){ //thread constructor
            mySocket = socket;
            InputStream tmpIn =null;
            OutputStream tmpOut = null;

            // Get the input and output streams, using temp objects because
            // member streams are final
            try {
                tmpIn = socket.getInputStream();
                tmpOut = socket.getOutputStream();
            } catch (IOException e) { }

            myInStream = tmpIn;
            myOutStream = tmpOut;
        }
        public void run(){
            byte[] buffer = new byte[1024]; // buffer store for the stream
            int bytes; // bytes returned from read()
            // Keep listening to the InputStream until an exception occurs
            while (true) {
                try {
                    bytes = myInStream.available();
                    if(bytes != 0){
                        SystemClock.sleep(100); //pause and wait for rest of data. Adjust this depending on your sending speed.
                        bytes = myInStream.available(); // how many bytes are ready to be read?
                        bytes = myInStream.read(buffer, 0, bytes); // record how many bytes we actually read
                        myHandler.obtainMessage(MESSAGE_READ, bytes, -1, buffer).sendToTarget(); //Send the obtained bytes to the UI activity
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                    break;
                }
            }
        }

        /* Call this from the main activity to send data to the remote device */
        public void write(String input) {
            byte[] bytes = input.getBytes();           //converts entered String into bytes
            try {
                myOutStream.write(bytes);
            } catch (IOException e) { }
        }

        /* Call this from the main activity to shutdown the connection */
        public void cancel() {
            try {
                mySocket.close();
            } catch (IOException e) { }
        }
    }



    //destroy items when app destroyed
    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(myReceiver1); //destroy broadcast receiver registration
        unregisterReceiver(myReceiver2);
    }









    /*Handler myHandler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(@NonNull Message msg) {
            switch(msg.what){
                case BLUETOOTH_OFF:
                    switchBT.setChecked(false);
                    break;
                case BLUETOOTH_ON:
                    switchBT.setChecked(true);
                    break;
            }

            return true;
        }
    });*/

    /*private class checkBtStatusClass extends Thread{
        public void run(){
            if(!bluetoothAdapter.isEnabled()){
                Message message = Message.obtain();
                message.what = BLUETOOTH_OFF;
                myHandler.sendMessage(message);
            }else {
                Message message = Message.obtain();
                message.what = BLUETOOTH_ON;
                myHandler.sendMessage(message);
            }
        }
    }*/


}
