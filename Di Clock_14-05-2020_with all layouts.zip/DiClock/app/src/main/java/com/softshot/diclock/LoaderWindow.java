package com.softshot.diclock;

import android.app.Activity;
import android.app.AlertDialog;
import android.view.LayoutInflater;

class LoaderWindow {

    //create object
    Activity activity;
    AlertDialog dialog;

    LoaderWindow(Activity myActivity){//constructer
        activity = myActivity;
    }

    void startLoadingDialog(){
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);

        LayoutInflater inflater = activity.getLayoutInflater();
        builder.setView(inflater.inflate(R.layout.activity_loader_window, null));
        builder.setCancelable(false); //when tuch the background not cancel the loading view

        dialog = builder.create();
        dialog.show();
    }

    void dismissDialog(){
        dialog.dismiss();
    }

}//end of class
