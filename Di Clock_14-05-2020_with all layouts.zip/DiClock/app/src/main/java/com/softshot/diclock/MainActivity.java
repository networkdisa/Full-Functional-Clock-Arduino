package com.softshot.diclock;

import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Set;
import java.util.UUID;


public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";

    static MainActivity instance;//01-make instance of MainActivity for access from ClockSetup activity

    TextView btStatus; //bluetooth status text view
    Button btOn; //bluetooth on button
    Button btOff; //bluetooth off button
    Button showPaired; //show paired devices button
    ListView listDevices;  //listView for paired / discover devices
    Button btnTestVal;
    Button clockSetup; //button for go to ClockSetup dialog

    private Set<BluetoothDevice> myPairedDevices; //Set is A collection that contains no duplicate elements
    private ArrayAdapter<String> myArrayAdapter;  //for Listview

    BluetoothAdapter myBluetoothAdapter; //creating object of BluetoothAdapter.
    private BluetoothSocket myBTSocket = null; // bi-directional client-to-client data path
    private ConnectedThread myConnectedThread; // bluetooth background worker thread to send and receive data

    //int object for enable the BlueTooth
    int REQUEST_ENABLE_BLUETOOTH = 1;

    // "random" unique identifier for initiate connectivity
    private static final UUID BTMODULEUUID  = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    //constants for Handler usability
    private final static int MESSAGE_READ = 2; // used in bluetooth handler to identify message update
    private final static int CONNECTING_STATUS = 3; // used in bluetooth handler to identify message status


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        instance = this;//02-make instance of MainActivity for access from ClockSetup activity

        findViewByIdes(); //initialize all UI components.

        clockSetup.setVisibility(View.GONE); //change visibility of 'SETUP YOUR CLOCK' button.

        myBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

        checkBluetoothStatus(); //check bluetooth status when MainActivity start

        bluetoothOn(); //Enabling bluetooth

        //BroadcastReceiver registration for get currant bluetooth status
        IntentFilter BTIntent = new IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED);
        registerReceiver(myBroadcastReceiver1, BTIntent);

        //BroadcastReceiver registration for find connected bluetooth device is disconnected.(the disconnected status showing after 15seconds)
        IntentFilter BTdeviceDisconnected = new IntentFilter(BluetoothDevice.ACTION_ACL_DISCONNECTED);
        this.registerReceiver(myBroadcastReceiver3, BTdeviceDisconnected);

        //assign array adapter to ListView and it format(simple_list_item_1)
        myArrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1);
        listDevices.setAdapter(myArrayAdapter);
        listDevices.setOnItemClickListener(myDeviceListClick); //ListView item click event

    }//end of onCreate

    //03-make instance of MainActivity for access from ClockSetup activity
    public static MainActivity getInstance(){
        return instance;
    }

    /*
    method for instantiate UI elements
    */
    private void findViewByIdes() {
        btStatus = (TextView) findViewById(R.id.txtBtStatus);
        btOn = (Button) findViewById(R.id.btnBtOn);
        btOff = (Button) findViewById(R.id.btnBtOff);
        showPaired = (Button) findViewById(R.id.btnPairedDevices);
        listDevices = (ListView) findViewById(R.id.listViewForDevices);
        clockSetup = (Button) findViewById(R.id.btnSetupClock);
    }

    /*
    enabling bluetooth
    */
    private void bluetoothOn() {
        if(!myBluetoothAdapter.isEnabled()) {
            Intent enableBTIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivity(enableBTIntent);
        }
    }

    /*
    enabling bluetooth on when "ENABLE BLUETOOTH" button click
    */
    public void btnBluetoothOn(View view) {
        bluetoothOn();
        Log.d(TAG, "btnBluetoothOn: Enabling BT.");
    }

    /*
    disabling bluetooth on when "DISABLE BLUETOOTH" button click
    */
    public void btnBluetoothOff(View view) {
        myBluetoothAdapter.disable();
        Log.d(TAG, "btnBluetoothOff: disabling BT.");
    }

    /*
    paired device listing when "SHOW PAIRED DEVICE" button click
    */
    public void btnShowPairedDevices(View view) {
        showPairedDevices();
    }

    /*
    bluetooth discovery process start when "DISCOVER DEVICE" button click
    */
    public void btnDiscoverDevices(View view) {
        discoverDevices();
    }

    /*
    go to ClockSetup intent when "SETUP YOUR CLOCK" button click
    */
    public void btnSetupClock(View view) {
        gotoClockSetupIntent();
    }

    /*
    public function for send data to connected device
    */
    public void sendData(String data){
        if(myConnectedThread != null){
            myConnectedThread.write(data);
        }
    }


    /*
    method for find current bluetooth status
    */
    private void checkBluetoothStatus() {
        if(myBluetoothAdapter == null){
            btStatus.setText("Bluetooth not support");
            btOn.setEnabled(false);
            btOff.setEnabled(false);
        }
        if(myBluetoothAdapter.isEnabled()){
            btStatus.setText("Bluetooth Enabled");
            btOn.setEnabled(false);
        }else{
            btStatus.setText("Bluetooth Disabled");
            btOff.setEnabled(false);
        }
    }

    /*
    show paired devices method
    */
    private void showPairedDevices(){
        myPairedDevices = myBluetoothAdapter.getBondedDevices();
        if(myBluetoothAdapter.isEnabled()){
            if(myBluetoothAdapter.isDiscovering()){ //check bluetooth discovery process running, if it is stop discoveryprocess
                myBluetoothAdapter.cancelDiscovery();
                Toast.makeText(getApplicationContext(), "Bluetooth discovery stopped", Toast.LENGTH_SHORT).show();
            }

            myArrayAdapter.clear(); //clear existing content
            for (BluetoothDevice device : myPairedDevices){
                //add checking for only show paired clocks.
                myArrayAdapter.add(device.getName() + "\n" + device.getAddress()); //
                Toast.makeText(getApplicationContext(), "Paired devices listing completed", Toast.LENGTH_SHORT).show();
            }
        }else {
            Toast.makeText(getApplicationContext(), "Bluetooth not enabled", Toast.LENGTH_LONG).show();
        }

    }

    /*
    Discover new bluetooth devices method
    */
    private void discoverDevices(){
        if(myBluetoothAdapter.isEnabled()){
            if(myBluetoothAdapter.isDiscovering()) { //check discovery process already running
                myBluetoothAdapter.cancelDiscovery();
                Toast.makeText(getApplicationContext(), "Running bluetooth discovery process stopped", Toast.LENGTH_LONG).show();
            }
            if(!myBluetoothAdapter.isDiscovering()){
                myArrayAdapter.clear(); //clear existing content
                myBluetoothAdapter.startDiscovery();

                IntentFilter discoverDevicesIntent = new IntentFilter(BluetoothDevice.ACTION_FOUND);
                registerReceiver(myBroadcastReceiver2, discoverDevicesIntent);

                Toast.makeText(getApplicationContext(), "Bluetooth discovery process Started", Toast.LENGTH_SHORT).show();
            }
        }else {
            Toast.makeText(getApplicationContext(), "Bluetooth not enabled", Toast.LENGTH_LONG).show();
        }
    }

    /*
    Listview click event method
    */
    private AdapterView.OnItemClickListener myDeviceListClick =new AdapterView.OnItemClickListener() {
        @Override
        public void onItemClick(AdapterView<?> parent, View v, int position, long id) {
            if(!myBluetoothAdapter.isEnabled()){
                Toast.makeText(getApplicationContext(), "Bluetooth not On", Toast.LENGTH_LONG).show();
                return;
            }

            btStatus.setText("Connecting...");

            // Get the device MAC address, which is the last 17 chars in the View
            String deviceInfo = ((TextView) v).getText().toString();
            final String deviceMac = deviceInfo.substring(deviceInfo.length() - 17);
            final String deviceName = deviceInfo.substring(0,deviceInfo.length() - 17);

            //thread that initiates a Bluetooth connection
            new Thread(){
                public void run(){
                    boolean fail = false; //for mark socket creation status

                    BluetoothDevice device = myBluetoothAdapter.getRemoteDevice(deviceMac);

                    try {
                        myBTSocket = createBluetoothSocket(device);
                    } catch (IOException e) {
                        fail = true;
                        Toast.makeText(getApplicationContext(), "Socket creation fail", Toast.LENGTH_LONG).show();
                    }
                    // Establish the Bluetooth socket connection.
                    try {
                        myBTSocket.connect();
                    } catch (IOException e) {
                        try {
                            fail = true;
                            myBTSocket.close();
                            myHandler.obtainMessage(CONNECTING_STATUS, -1, -1) .sendToTarget();
                        } catch (IOException e2) {
                            //insert code to deal with this
                            Toast.makeText(getApplicationContext(), "Socket creation fail", Toast.LENGTH_LONG).show();
                        }
                    }
                    if(fail == false){
                        myConnectedThread = new ConnectedThread(myBTSocket);
                        myConnectedThread.start();

                        myHandler.obtainMessage(CONNECTING_STATUS, 1, -1, deviceName).sendToTarget();
                    }
                }
            }.start();
        }
    };

    /*
    add BluetoothSocket to connected deviceMac and return it attaching UUID
    */
    private BluetoothSocket createBluetoothSocket(BluetoothDevice device) throws IOException {
        return  device.createRfcommSocketToServiceRecord(BTMODULEUUID);
    }

    //Handler object for update UI while running background Thread
    Handler myHandler = new Handler() {
        public void handleMessage(android.os.Message msg){
            if(msg.what == CONNECTING_STATUS){
                if(msg.arg1 == 1){
                    btStatus.setText("Connected to Device: " + (String)(msg.obj));
                    gotoClockSetupIntent();
                    clockSetup.setVisibility(View.VISIBLE);
                }else {
                    btStatus.setText("Connection Failed");
                }
            }

            if(msg.what == MESSAGE_READ){
                String readMessage = null;
                try {
                    readMessage = new String((byte[]) msg.obj, "UTF-8");
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                }
            }
        }
    };

    /*
    method for go to "ClockSetup" intent
    */
    public void gotoClockSetupIntent(){
        Intent setupClockIntent = new Intent(this, ClockSetup.class);
        startActivity(setupClockIntent);
    }

    /*
    broadcast receiver for current bluetooth status change check
    */
    private final BroadcastReceiver myBroadcastReceiver1 = new BroadcastReceiver() {
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            // When discovery finds a device
            if (action.equals(myBluetoothAdapter.ACTION_STATE_CHANGED)) {
                final int state = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, myBluetoothAdapter.ERROR);

                switch(state){
                    case BluetoothAdapter.STATE_OFF:
                        btStatus.setText("Bluetooth disabled");
                        btOn.setEnabled(true);
                        btOff.setEnabled(false);
                        clockSetup.setVisibility(View.GONE);
                        break;
                    case BluetoothAdapter.STATE_TURNING_OFF:
                        btStatus.setText("Turning Bluetooth off...");
                        break;
                    case BluetoothAdapter.STATE_ON:
                        btStatus.setText("Bluetooth on");
                        btOn.setEnabled(false);
                        btOff.setEnabled(true);
                        break;
                    case BluetoothAdapter.STATE_TURNING_ON:
                        btStatus.setText("Turning Bluetooth on...");
                        break;
                }
            }
        }
    };

    /*
     * Broadcast Receiver for listing devices that are not yet paired
     * -Executed by discoverDevices() method.
    */
    private BroadcastReceiver myBroadcastReceiver2 = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            final String action = intent.getAction();
            Log.d(TAG, "onReceive: ACTION FOUND.");

            if (action.equals(BluetoothDevice.ACTION_FOUND)){
                BluetoothDevice device = intent.getParcelableExtra (BluetoothDevice.EXTRA_DEVICE);
                Log.d(TAG, "onReceive: " + device.getName() + ": " + device.getAddress());
                // add the name to the list
                myArrayAdapter.add(device.getName() + "\n" + device.getAddress());
                myArrayAdapter.notifyDataSetChanged(); //refresh listview when change occur
            }
        }
    };

    /*
    BroadcastReceiver for Connected device status check--disconnection from a remote bluetooth device.
    */
    private final BroadcastReceiver myBroadcastReceiver3 = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();

            if (BluetoothDevice.ACTION_ACL_DISCONNECTED.equals(action)){ //take 15 seconds to catch this status
                btStatus.setText("Device disconnected");
                clockSetup.setVisibility(View.GONE);
            }
        }
    };

    /*
    Bluetooth thread for RX/TX data with remote device
    */
    private class ConnectedThread extends Thread{
        private final BluetoothSocket mySocket;
        private final InputStream myInStream;
        private final OutputStream myOutStream;

        public ConnectedThread(BluetoothSocket socket){ //thread constructor
            mySocket = socket;
            InputStream tmpIn =null;
            OutputStream tmpOut = null;

            // Get the input and output streams, using temp objects because
            // member streams are final
            try {
                tmpIn = socket.getInputStream();
                tmpOut = socket.getOutputStream();
            } catch (IOException e) { }

            myInStream = tmpIn;
            myOutStream = tmpOut;
        }
        public void run(){
            byte[] buffer = new byte[1024]; // buffer store for the stream
            int bytes; // bytes returned from read()
            // Keep listening to the InputStream until an exception occurs
            while (true) {
                try {
                    bytes = myInStream.available();
                    if(bytes != 0){
                        SystemClock.sleep(100); //pause and wait for rest of data. Adjust this depending on your sending speed.
                        bytes = myInStream.available(); // how many bytes are ready to be read?
                        bytes = myInStream.read(buffer, 0, bytes); // record how many bytes we actually read
                        myHandler.obtainMessage(MESSAGE_READ, bytes, -1, buffer).sendToTarget(); //Send the obtained bytes to the UI activity
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                    break;
                }
            }
        }

        /* Call this from the main activity to send data to the remote device */
        public void write(String input) {
            byte[] bytes = input.getBytes();           //converts entered String into bytes
            try {
                myOutStream.write(bytes);
            } catch (IOException e) { }
        }

        /* Call this from the main activity to shutdown the connection */
        public void cancel() {
            try {
                mySocket.close();
            } catch (IOException e) { }
        }
    }

    /*
    unregistering BroadcastReceivers
    */
    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(myBroadcastReceiver1);
        unregisterReceiver(myBroadcastReceiver2);
        unregisterReceiver(myBroadcastReceiver3);
        //mBluetoothAdapter.cancelDiscovery();
    }




}//end of mainclass
